# web-teknolojileri-projesi

###   Projenin Amacı:
- Kendimi ve yaşadığım şehri tanıtan kişisel bir web sitesi geliştirmek.


###   İçerik:

  ##### Ana Sayfada
    - Diğer sayfalara ulaşılabilicek menü
    
  ##### Hakkında Sayfası
    - Kişisel ilgi alanlarım vb. bilgiler
    
  ##### Özgeçmiş Sayfası    
    - Eğitim bilgileri table ve div kullanarak oluşturulmalı
    
  ##### Şehrim Sayfası  
    - Şehre ait kısa bir metin,
    - En az 4 mekana ait fotoğrafın olduğu bir slider
    - Slider daki resimlere tıklandığında resimlere ait içerik sayfaları açılmalı
   
  ##### Mirasımız Sayfası
    - Şehirdeki kültürel bir mekanın tanıtımı 
    
  ##### Login Sayfası
    - Kullanıcıdan kullanıcı adı ve şifre istenmeli
    - Eğer kullanıcı adı ve şifre doğrulanırsa 'Hoşgeldiniz' mesajı verilmeli,
    - Eğer kullanıcı ad veya şifre yanlış ise login sayfasına geri dönülmeli,
    - Kullanıcı adının mail olup olmadığı,
    - Kullanıcı adı ve şifrenin boş olup olmadığı kontrol edilmeli,
    
  ##### İletişim Sayfası
    - Form elemanları kullanılmalı
    - Kontrol işlemleri javascript ile yapılmalı
    - Gönderilen form bilgileri başka bir sayfada görüntülenmeli
    
###    Proje Süreci
  - Projenin 4 farklı versiyonunu oluşturmayı planlıyorum.
    - İlk versiyonda sayfaların html dosyalarının yazılması ve gerekli dökümanın ve içeriğin toplanması.
    - Sayfaların tasarım kodlarının yazılması,
    - Gerekli javascript ve php dosyalarının tamamlanması,
    - Ve son olarak eksik gördüğüm ve eklemek istediğim kısımların eklenmesi.